package com.example.roberthsantos.homecutcliente.Adapters;

import android.view.View;

interface ItemClickListener {

    void onItemClick(View v, int pos);
}
